export interface Vote {
    likes: boolean;
}