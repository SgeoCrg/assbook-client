export const SERVER = "https://api.fullstackpro.es/assbook";//quitar lite
export const API_KEY = "Atvu8CHBTIby7K74kcdMvqYXgwo00iZhMnIhgXBXwVhq7VwknG0sbS2a1Sv_TjaW";