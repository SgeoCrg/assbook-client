export class AuthService {
    // Complete this class

    //Hacer logout - borra token y redirige a index.html
}
